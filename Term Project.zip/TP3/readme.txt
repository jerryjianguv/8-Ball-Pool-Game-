 
1. Project Description

Project Name: 8 Ball Pool Game!

Project Description: A fun 2 Player 8 Ball Pool Game that follows the general rules of 8 ball Pool Game. The Player could choose to move the mouse to find appropriate force and angle, and press the mouse to release the cue stick to hit the cue ball. Whoever first knocks in all the pool balls(without violating the general 8 ball pool rules) wins. There are two game modes: Two Player Mode(Player 1 vs Player 2), and One player Mode (Player 1 vs Adversary AI).

Press Space to start the game, and Click the mouse to choose a mode you would like to have fun with. At anytime, press H to proceed to the helper mode to check the rules and help message.

2. How to run the project?

Download all the files in the zip file, run 8BallPool.py in VS code as you would do running other python files.

3. Libraries needed:

Download and install pygame to play the background sounds.

4. ShortCut Command that exists:

There are none.